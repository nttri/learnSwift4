//
//  LoadScreenViewController.swift
//  demo24042018
//
//  Created by CPU12131 on 4/24/18.
//  Copyright © 2018 CPU12131. All rights reserved.
//

import UIKit

class LoadScreenViewController: UIViewController {

    @IBOutlet weak var loadingBar: UIProgressView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        perform(Selector("pushMainView"))
    }
    
    func pushMainView(){
//        for i in 1...10000{
//            loadingBar.setProgress(Float(i)/10000, animated: true)
//        }
        performSegue(withIdentifier: "showMainViewSegue", sender: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
